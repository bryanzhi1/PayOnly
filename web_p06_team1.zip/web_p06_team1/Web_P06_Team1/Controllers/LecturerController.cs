﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Web_P06_Team1.DAL;
using Web_P06_Team1.Models;

namespace Web_P06_Team1.Controllers
{
    public class LecturerController : Controller
    {
        private LecturerDAL lecturerContext = new LecturerDAL();

        public IActionResult ViewMentees()
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Lecturer"))
            {
                TempData["Message"] = "You must be logged in to access this page.";
                return RedirectToAction("Index", "LecturerLogin");
            }
            int MentorID = Convert.ToInt32(HttpContext.Session.GetInt32("LecturerID")); //Get MentorID
            List<Student> studentList = lecturerContext.GetMentees(MentorID);
            return View(studentList);
        }

        public ActionResult PostSuggestion(int? sId, string sName)
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Lecturer"))
            {
                TempData["Message"] = "You must be logged in to access this page.";
                return RedirectToAction("Index", "LecturerLogin");
            }
            TempData["Name"] = sName;
            HttpContext.Session.SetString("StudentID", sId.ToString());

            return View();
        }

        [HttpPost]
        public ActionResult SuggestionPost(IFormCollection formData)
        {
            int MentorID = Convert.ToInt32(HttpContext.Session.GetInt32("LecturerID")); //Get MentorID
            int StudentID = Convert.ToInt32(HttpContext.Session.GetString("StudentID"));
            string description = formData["txtDescription"].ToString();

            bool success = lecturerContext.UpSuggestion(MentorID, StudentID, description);
            HttpContext.Session.Remove("StudentID"); //Reset session for studentID

            TempData["Message"] = "Successfully posted suggestion.";
            return RedirectToAction("ViewMentees");
        }

        public IActionResult ViewSuggestions(){
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Lecturer"))
            {
                TempData["Message"] = "You must be logged in to access this page.";
                return RedirectToAction("Index", "LecturerLogin");
            }

            int MentorID = Convert.ToInt32(HttpContext.Session.GetInt32("LecturerID")); ;
            List<Suggestion> suggestionList = lecturerContext.GetSuggestions(MentorID);

            return View(suggestionList);
        }
    }
}