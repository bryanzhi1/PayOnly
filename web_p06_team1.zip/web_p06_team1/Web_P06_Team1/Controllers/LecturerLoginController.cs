﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Web_P06_Team1.DAL;
using Web_P06_Team1.Models;

namespace Web_P06_Team1.Controllers
{
    public class LecturerLoginController : Controller
    {
        private LecturerDAL lecturerContext = new LecturerDAL();

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult LecturerMain()
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Lecturer"))
            {
                TempData["Message"] = "You must be logged in to access this page.";
                return RedirectToAction("Index");
            }
            return View();
        }

        public IActionResult PasswordChange()
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Lecturer"))
            {
                TempData["Message"] = "You must be logged in to access this page.";
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpPost]
        public ActionResult LecturerLogin(IFormCollection formData)
        {
            string loginID = formData["txtLoginID"].ToString().ToLower();
            string password = formData["txtPassword"].ToString();
            bool validCredentials = lecturerContext.accountChecker(loginID, password);


            if (validCredentials == true)
            {
                HttpContext.Session.SetString("LoginID", loginID);
                HttpContext.Session.SetString("Role", "Lecturer");
                int MentorID = lecturerContext.GetMentorID(loginID);
                HttpContext.Session.SetInt32("LecturerID", MentorID);
                return RedirectToAction("LecturerMain");
            }

            else
            {
                TempData["Message"] = "Invalid Login Credentials";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public ActionResult Create(Lecturer lecturer, IFormCollection formData)
        {
            if (ModelState.IsValid)
            {
                bool IsEmailExist = lecturerContext.IsEmailExist(formData["Email"].ToString());

                if (IsEmailExist == false)
                {
                    lecturer.LecturerId = lecturerContext.Add(lecturer);
                    TempData["Message"] = "You have registered sucessfully.";
                    return RedirectToAction("Index");
                }

                else
                {
                    TempData["Message"] = "Email already exists.";
                    return RedirectToAction("Index");
                }
            }

            else
            {
                TempData["Message"] = "An error has occurred. Please try again.";
                return RedirectToAction("Index");
            }
        }

       [HttpPost]
       public ActionResult ChangePassword(IFormCollection formData)
        {
            string oldpwd = formData["txtOldPwd"].ToString();
            string newpwd = formData["txtnewPwd"].ToString();
            string cfmpwd = formData["txtCfmPwd"].ToString();
            string email = HttpContext.Session.GetString("LoginID");

            bool correctOldPwd = lecturerContext.accountChecker(email, oldpwd); //Verify old password
            
            if (correctOldPwd == true)
            {
                if (newpwd == cfmpwd)
                {
                    //Check for 1 numeric char in password
                    bool meetsReq = false;
                    bool result = false;
                    int count = 0;
                    foreach(char c in newpwd){
                        result = false;
                        result = Char.IsDigit(c);
                        count += 1;

                        if (result == true){
                            meetsReq = true;
                        }
                    }
                    
                    if (meetsReq == true && count >=8){
                        bool updated = lecturerContext.changePassword(email, newpwd);

                        if (updated == true)
                        {
                            TempData["Message"] = "You have sucessfully changed your password.";
                            return RedirectToAction("PasswordChange");
                        }

                        else
                        {
                            TempData["Message"] = "An unknown error occured.";
                            return RedirectToAction("PasswordChange");
                        }
                    }

                    else{
                        TempData["Message"] = "Your password must contain at least 1 numeric character be at least 8 characters long.";
                        return RedirectToAction("PasswordChange");
                    }
                    
                }

                else
                {
                    TempData["Message"] = "New passwords do not match. No changes were made.";
                    return RedirectToAction("PasswordChange");
                }
            }

            else
            {
                TempData["Message"] = "Incorrect old password. No changes were made.";
                return RedirectToAction("PasswordChange");
            }
        }

        public ActionResult LogOut()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
    }
}