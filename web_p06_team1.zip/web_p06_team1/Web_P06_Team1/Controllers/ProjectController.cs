﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web_P06_Team1.DAL;
using Microsoft.AspNetCore.Http;
using Web_P06_Team1.Models;

namespace Web_P06_Team1.Controllers
{
    public class ProjectController : Controller
    {
        ProjectDAL projectContext = new ProjectDAL();
        StudentDAL studentContext = new StudentDAL();

        public IActionResult Index()
        {
            if ((HttpContext.Session.GetString("Role") == null) || (HttpContext.Session.GetString("Role") != "Student"))
            {
                TempData["Message"] = "You must be logged in as a student to access this page.";
                return RedirectToAction("Index");
            }
            Student s = studentContext.currentStudent(HttpContext.Session.GetString("LoginID"));
            List<Project> projectList = projectContext.GetProject(s);
            return View(projectList);
        }

        public ActionResult Details(int id)
        {
            if ((HttpContext.Session.GetString("Role") == null) || (HttpContext.Session.GetString("Role") != "Student"))
            {
                TempData["Message"] = "You must be logged in as a student to access this page.";
                return RedirectToAction("Index");
            }
            // for the displaying of the details
            Project p = projectContext.getCurrentProject(id);
            ProjectViewModel pvm = projectContext.getMembers(p);
            pvm.projectID = p.projectID;
            pvm.title = p.title;
            pvm.description = p.description;
            pvm.projectPoster = p.projectPoster;
            pvm.projectURL = p.projectURL;
            return View(pvm);
        }

        [HttpGet]
        public ActionResult Create()
        {
            if ((HttpContext.Session.GetString("Role") == null) || (HttpContext.Session.GetString("Role") != "Student"))
            {
                TempData["Message"] = "You must be logged in as a student to access this page.";
                return RedirectToAction("Index");
            }
            // for the display of the create form
            return View();
        }

        [HttpPost]
        public ActionResult Create(Project p)
        {
            if (ModelState.IsValid)
            {
                projectContext.AddProject(p, studentContext.currentStudent(HttpContext.Session.GetString("LoginID")));
                return RedirectToAction("Index");
            }
            else
            {
                return View(p);
            }
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            if ((HttpContext.Session.GetString("Role") == null) || (HttpContext.Session.GetString("Role") != "Student"))
            {
                TempData["Message"] = "You must be logged in as a student to access this page.";
                return RedirectToAction("Index");
            }
            // for the updating of the information
            return View();
        }

        [HttpPost]
        public ActionResult Edit(ProjectViewModel p)
        {
            if (ModelState.IsValid)
            {
                projectContext.UpdateProject(p);
                projectContext.UpdateProjectMember(p.studentList);
                return RedirectToAction("Index");
            }
            else
                return View(p);
        }
    }
}