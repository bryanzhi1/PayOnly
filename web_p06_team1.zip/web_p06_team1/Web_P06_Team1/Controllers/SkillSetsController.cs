﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Web_P06_Team1.DAL;
using Web_P06_Team1.Models;

namespace Web_P06_Team1.Controllers
{
    public class SkillSetsController : Controller
    {
        private SkillSetDAL SkillSetContext = new SkillSetDAL();
        public IActionResult Index()
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
                (HttpContext.Session.GetString("Role") != "SkillSet"))
            {
                return RedirectToAction("Index");
            }
            return View();

        }

        public IActionResult SkillSetEdit()
        {
            return View();
        }

        public IActionResult StudentSkillSets()
        {
            return View();
        }

        public IActionResult StdSearch(IFormCollection formData)
        {
            string StdId = formData["txtStudentId"].ToString();
            bool valid = SkillSetContext.CheckId(StdId);

            if (valid)
            {
                HttpContext.Session.SetString("StudentID", StdId);
                HttpContext.Session.SetString("Role", "SkillSet");

                return RedirectToAction("StudentSkillsets");
            }
            else
            {
                TempData["Message"] = "Invalid Login Credentials";
                return RedirectToAction("Index");
            }
        }

        public IActionResult SklSearch(IFormCollection formData)
        {
            string Skill = formData["txtSearchSkill"].ToString();
            bool valid = SkillSetContext.CheckSkill(Skill);

            if (valid)
            {
                HttpContext.Session.SetString("SkillSetName",Skill);
                HttpContext.Session.SetString("Role","SkillSet");
                return RedirectToAction("SkillSetEdit");
            }
            else
            {
                TempData["message"] = "None or too many Skillsets found";
                return RedirectToAction("Index");
            }
        }

        public IActionResult UpdateSkillName(IFormCollection formdata)
        {
            string NewName = formdata["txtSkillName"].ToString();

            string OldName = HttpContext.Session.GetString("SkillSetName");

            
            bool existing = SkillSetContext.CheckSkill(NewName);
            if (existing == false)
            {
                bool successful = SkillSetContext.ChangeName(NewName, OldName);
                HttpContext.Session.SetString("SkillSetName", NewName);
                return RedirectToAction("SkillSetEdit");
                
            }
            else
            {
                TempData["message"] = "SkillSet with chosen name already exists";
                return RedirectToAction("SkillSetEdit");
            }
        }

        public IActionResult RmSkill(IFormCollection formData)
        {
            string SkillName = HttpContext.Session.GetString("SkillSetName");
            bool InUse = false;
            bool existing = SkillSetContext.CheckSkill(SkillName);
            if (existing)
            {
                List<int> StdList = SkillSetContext.GetAssignedStd(SkillName);
                foreach (int i in StdList)
                {
                    InUse = true;
                }

                if (InUse)
                {
                    TempData["message"] = "Skill is currently assigned to student";
                }
                else
                {
                    bool successful = SkillSetContext.RemoveSkill(SkillName);
                }

                

            }
            else
            {
                TempData["message"] = "Skill not Found";
            }
            return RedirectToAction("SkillSetEdit");
        }

        public IActionResult AddSkillSet(IFormCollection formData)
        {
            string SkillName = formData["txtAddSkill"].ToString();

            bool existing = SkillSetContext.CheckSkill(SkillName);
            if (existing)
            {
                bool suceeded = SkillSetContext.AddSkill(SkillName);
                HttpContext.Session.SetString("SkillSetName",SkillName);
                return RedirectToAction("SkillSetEdit");
            }
            else
            {
                TempData["message"] = "Skill Name already exists";
                return RedirectToAction("SkillSetEdit");
            }

        }

        public IActionResult AddStdSkill(IFormCollection formData)
        {
            string SkillName = formData["txtAddSkill"].ToString();

            int StdID = Convert.ToInt32(HttpContext.Session.GetString("StudentID"));
            int SkillID = SkillSetContext.GetSkillID(SkillName);
            if (SkillID!= 0)
            {
                bool successful = SkillSetContext.AddStdSkill(SkillID,StdID);
            }
            else
            {
                TempData["message"] = "Skill Not found";
            }

            return RedirectToAction("StudentSkillSets");
        }

        public IActionResult RemoveStdSkill(IFormCollection formData)
        {
            string SkillName = formData["txtRmSkill"];
            int StdID = Convert.ToInt32(HttpContext.Session.GetString("StudentID"));
            int SkillID = SkillSetContext.GetSkillID(SkillName);

            if (SkillID != 0)
            {
                bool successful = SkillSetContext.RemoveStdSkill(SkillName, SkillID);

            }

            return RedirectToAction("StudentSkillSets");
        }

        

    } 
}