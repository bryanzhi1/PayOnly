﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Web_P06_Team1.DAL;
using Web_P06_Team1.Models;

namespace Web_P06_Team1.Controllers
{
    public class StudentController : Controller
    {
        private StudentDAL StudentContext = new StudentDAL();

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult StudentMain(string email)
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Student"))
            {
                return RedirectToAction("Index");
            }
            Student s = StudentContext.currentStudent(HttpContext.Session.GetString("LoginID"));
            return View(s);
        }

        // Student Login Function
        [HttpPost]
        public ActionResult StudentLogin(IFormCollection formData)
        {
            string loginId = formData["txtLoginID"].ToString().ToLower();
            string password = formData["txtPassword"].ToString();

            bool validCredentials = StudentContext.accountChecker(loginId, password);

            if (validCredentials == true)
            {
                HttpContext.Session.SetString("LoginID", loginId);
                HttpContext.Session.SetString("Role", "Student");

                return RedirectToAction("StudentMain");
            }

            else
            {
                TempData["Message"] = "Invalid Login Credentials";
                return RedirectToAction("Index");
            }

        }
        // Add Student Details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Student student)
        {
            //if(ModelState.IsValid)
            //{
                student.StudentId = StudentContext.Add(student);
                return RedirectToAction("Index");
            //}
            //else
            //{
                //return View(student);
            //}
        }
        public ActionResult returnStudent(string email)
        {
            Student s = StudentContext.currentStudent(email);
            return View(s);
        }

        // Log out Function
        public ActionResult LogOut()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
    }
}