﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Web_P06_Team1.DAL;
using Web_P06_Team1.Models;

namespace Web_P06_Team1.Controllers
{
    public class StudentLoginController : Controller
    {
        private StudentDAL studentContext = new StudentDAL();

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult StudentMain()
        {
            if ((HttpContext.Session.GetString("Role") == null) ||
            (HttpContext.Session.GetString("Role") != "Student"))
            {
                return RedirectToAction("Index");
            }
                return View();
        }
        [HttpPost]
        public ActionResult StudentLogin(IFormCollection formData)
        {
            string loginID = formData["txtLoginID"].ToString().ToLower();
            string password = formData["txtPassword"].ToString();
            bool validCredentials = studentContext.accountChecker(loginID, password);

            if (validCredentials == true)
            {
                HttpContext.Session.SetString("LoginID", loginID);
                HttpContext.Session.SetString("Role", "Student");

                return RedirectToAction("StudentMain");
            }

            else
            {
                TempData["Message"] = "Invalid Login Credentials";
                return RedirectToAction("Index");
            }
        }
        [HttpPost]
        public ActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                student.StudentId = studentContext.Add(student);
                TempData["Message"] = "You have register sucessfully.";
                return RedirectToAction("Index");
            }

            else
            {
                TempData["Message"] = "An error has occurred. Please try again.";
                return RedirectToAction("Index");
            }
        }
        public ActionResult LogOut()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
    }
}