﻿using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using Web_P06_Team1.Models;
using System.Collections.Generic;
using System;

namespace Web_P06_Team1.DAL
{
    public class LecturerDAL
    {
        private IConfiguration Configuration { get; set; }
        private SqlConnection conn;

        public LecturerDAL()
        {
            var builder = new ConfigurationBuilder()
           .SetBasePath(Directory.GetCurrentDirectory())
           .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "Student_EPorfolioConnectionString");
            conn = new SqlConnection(strConn);
        }

        public bool accountChecker(string email, string pwd)
        {
            SqlCommand cmd = new SqlCommand
                ("SELECT LecturerID, Name FROM Lecturer WHERE EmailAddr=@selectedEmail AND Password = @selectedPwd", conn);
            cmd.Parameters.AddWithValue("@selectedEmail", email);
            cmd.Parameters.AddWithValue("@selectedPwd", pwd);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "AccountDetails");
            conn.Close();

            if (result.Tables["AccountDetails"].Rows.Count == 1)
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        public int Add(Lecturer lecturer)
        {
                //Generate ID and add lecturer to database and return true
                SqlCommand cmd1 = new SqlCommand
               ("INSERT INTO Lecturer (Name, EmailAddr, Password, Description) " +
               "OUTPUT INSERTED.LecturerID " +
               "VALUES(@name, @emailadd, @pwd, @description)", conn);

                cmd1.Parameters.AddWithValue("@name", lecturer.Name.ToString());
                cmd1.Parameters.AddWithValue("@emailadd", lecturer.Email.ToString());
                cmd1.Parameters.AddWithValue("@pwd", "p@55Mentor");
                cmd1.Parameters.AddWithValue("@description", lecturer.Description.ToString());

                conn.Open();
                lecturer.LecturerId = (int)cmd1.ExecuteScalar(); //Auto generate ID
                conn.Close();

                return lecturer.LecturerId;
            
        }

        public bool IsEmailExist(string email)
        {
            //Check for existing email
            SqlCommand cmd = new SqlCommand
               ("SELECT LecturerID FROM Lecturer WHERE EmailAddr=@selectedEmail", conn);
            cmd.Parameters.AddWithValue("@selectedEmail", email);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "AccountDetails");
            conn.Close();

            if (result.Tables["AccountDetails"].Rows.Count > 0)
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        public bool changePassword(string email, string newpwd)
        {
            SqlCommand cmd = new SqlCommand("UPDATE Lecturer SET Password = @pwd WHERE EmailAddr = @loginid", conn);

            cmd.Parameters.AddWithValue("@pwd", newpwd);
            cmd.Parameters.AddWithValue("@loginid", email);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            return true;
        }

        public int GetMentorID(string loginID)
        {
            SqlCommand cmd = new SqlCommand("SELECT LecturerID FROM Lecturer WHERE EmailAddr=@loginid", conn);
            cmd.Parameters.AddWithValue("@loginid", loginID);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();

            conn.Open();
            da.Fill(result, "MentorDetails");
            conn.Close();

            int MentorID = 0;

            foreach (DataRow row in result.Tables["MentorDetails"].Rows)
            {
                MentorID = Convert.ToInt32(row["LecturerID"]);
            }

            return MentorID;
        }

        public List<Student> GetMentees(int MentorID)
        {
            SqlCommand cmd = new SqlCommand(
             "SELECT * FROM Student WHERE MentorID = @mentorid", conn);

            cmd.Parameters.AddWithValue("@mentorid", MentorID);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();

            conn.Open();
            da.Fill(result, "StudentDetails");
            conn.Close();

            List<Student> studentList = new List<Student>();
            foreach (DataRow row in result.Tables["StudentDetails"].Rows)
            {
                studentList.Add(
                    new Student
                    {
                        StudentId = Convert.ToInt32(row["StudentID"]),
                        Name = row["Name"].ToString(),
                        Course = row["Course"].ToString(),
                        Photo = row["Photo"].ToString(),
                        Description = row["Description"].ToString(),
                        Achievement = row["Achievement"].ToString(),
                        ExternalLink = row["ExternalLink"].ToString(),
                        Email = row["EmailAddr"].ToString(),
                        Password = row["Password"].ToString(),
                        MentorId = Convert.ToInt32(row["MentorID"])
                    }
                    );
            }

            return studentList;
        }

        public bool UpSuggestion(int MentorID, int StudentID, string desc)
        {
            SqlCommand cmd = new SqlCommand(
                "INSERT INTO Suggestion (LecturerID, StudentID, Description, Status, DateCreated) " +
                "OUTPUT INSERTED.SuggestionID " +
                "VALUES(@mid, @sid, @desc, @stat, GETDATE())", conn);

            cmd.Parameters.AddWithValue("@mid", MentorID);
            cmd.Parameters.AddWithValue("@sid", StudentID);
            cmd.Parameters.AddWithValue("@desc", desc);
            cmd.Parameters.AddWithValue("@stat", "N");

            conn.Open();
            int SuggestionID = (int)(cmd.ExecuteScalar());
            conn.Close();

            return true;
        }

        public List<Suggestion> GetSuggestions(int MentorID){
            SqlCommand cmd = new SqlCommand(
                "SELECT * FROM Suggestion WHERE LecturerID = @mid", conn
            );

            cmd.Parameters.AddWithValue("@mid", MentorID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "SuggestionsResult");
            conn.Close();

            List<Suggestion> suggestionList = new List<Suggestion>();

            foreach(DataRow row in result.Tables["SuggestionsResult"].Rows){
                suggestionList.Add(
                new Suggestion{
                    SuggestionId = Convert.ToInt32(row["SuggestionID"]),
                    LecturerId = Convert.ToInt32(row["LecturerID"]),
                    StudentId = Convert.ToInt32(row["StudentID"]),
                    Description = row["Description"].ToString(),
                    Status = Convert.ToChar(row["Status"]),
                    DateCreated = Convert.ToDateTime(row["DateCreated"])
                }
                );
            }

            foreach (Suggestion s in suggestionList)
            {
                s.StudentName = GetStudentName(Convert.ToInt32(s.StudentId));
            }

            return suggestionList;
        }

        public string GetStudentName(int studentId)
        {
            string name = "";
                SqlCommand cmd = new SqlCommand("SELECT Name FROM Student WHERE StudentID = @sid", conn);
                cmd.Parameters.AddWithValue("@sid", studentId);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet result = new DataSet();

                conn.Open();
                da.Fill(result, "NameResult");
                conn.Close();
                foreach (DataRow row in result.Tables["NameResult"].Rows)
                {
                    name = row["Name"].ToString();
                }

            return name;
        }
    }
}
