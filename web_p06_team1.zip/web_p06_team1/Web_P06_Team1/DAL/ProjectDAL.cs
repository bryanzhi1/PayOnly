﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using Web_P06_Team1.Models;

namespace Web_P06_Team1.DAL
{
    public class ProjectDAL
    {
        private IConfiguration Configuration { get; set; }
        private SqlConnection conn;

        public ProjectDAL()
        {
            var builder = new ConfigurationBuilder()
           .SetBasePath(Directory.GetCurrentDirectory())
           .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
            "Student_EPorfolioConnectionString");
            conn = new SqlConnection(strConn);
        }
        
        public List<Project> GetProject(Student s)
        {
            SqlCommand cmd = new SqlCommand("SELECT p.* FROM Project p " +
            "INNER JOIN ProjectMember pm ON p.ProjectID = pm.ProjectID " +
            "WHERE StudentID = @studentID", conn);

            cmd.Parameters.AddWithValue("@studentID", s.StudentId);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            int rows = da.Fill(result, "Project");
            conn.Close();

            List<Project> projectList = new List<Project>();
            if (rows == 0)
                return projectList;
            else
            {
                foreach (DataRow dr in result.Tables["Project"].Rows)
                {
                    projectList.Add(new Project
                    {
                        projectID = Convert.ToInt32(dr["ProjectID"]),
                        title = dr["Title"].ToString(),
                        description = dr["Description"].ToString(),
                        projectPoster = dr["ProjectPoster"].ToString(),
                        projectURL = dr["ProjectURL"].ToString()
                    });
                }
            }
            return projectList;
        }

        public Project getCurrentProject(int id)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM Project " +
            "WHERE ProjectID = @projectID ", conn);

            cmd.Parameters.AddWithValue("@projectID", id);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "Project");
            conn.Close();

            Project currentproj = new Project();
            DataRow dr = result.Tables["Project"].Rows[0];
            currentproj.projectID = Convert.ToInt32(dr["ProjectID"]);
            currentproj.title = dr["Title"].ToString();
            currentproj.description = dr["Description"].ToString();
            currentproj.projectPoster = dr["ProjectPoster"].ToString();
            currentproj.projectURL = dr["ProjectURL"].ToString();

            return currentproj;
        }

        public ProjectViewModel getMembers(Project p)
        {
            SqlCommand cmd = new SqlCommand("SELECT s.Name, pm.Role FROM ProjectMember pm " +
            "INNER JOIN Student s ON s.StudentID = pm.StudentID " +
            "WHERE pm.ProjectID = @projectID ", conn);
            cmd.Parameters.AddWithValue("@projectID", p.projectID);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "Detail");
            conn.Close();

            ProjectViewModel pvm = new ProjectViewModel();
            List<String> members = new List<String>();
            List<String> roles = new List<string>();
            foreach (DataRow dr in result.Tables["Detail"].Rows)
            {
                members.Add(dr["Name"].ToString());
                roles.Add(dr["Role"].ToString());
            }
            pvm.studentList = members;
            pvm.roleList = roles;
            return pvm;
        }

        public int AddProject(Project p, Student s)
        {
            // add the project to the database
            SqlCommand cmd = new SqlCommand("INSERT INTO Project(Title, Description, ProjectPoster, ProjectURL) " +
            "OUTPUT INSERTED.ProjectID " +
            "VALUES(@Title, @Description, @ProjectPoster, @ProjectURL) ", conn);
            cmd.Parameters.AddWithValue("@Title", p.title);
            cmd.Parameters.AddWithValue("@Description", p.description);
            cmd.Parameters.AddWithValue("@ProjectPoster", p.projectPoster);
            cmd.Parameters.AddWithValue("@ProjectURL", p.projectURL);

            conn.Open();
            p.projectID = (int)cmd.ExecuteScalar();

            SqlCommand cmd2 = new SqlCommand("INSERT INTO ProjectMember(ProjectID, StudentID, Role) " +
            "VALUES(@ProjectID, @StudentID, @Role) ", conn);
            cmd2.Parameters.AddWithValue("@ProjectID", p.projectID);
            cmd2.Parameters.AddWithValue("@StudentID", s.StudentId);
            cmd2.Parameters.AddWithValue("@Role", "Leader");

            cmd2.ExecuteNonQuery();
            conn.Close();

            return p.projectID;
        }

        public void UpdateProject(ProjectViewModel p)
        {
            SqlCommand cmd = new SqlCommand("UPDATE Project " +
            "SET Description = @description, projectURL = @projectURL " +
            "WHERE ProjectID = @projectID ", conn);
            cmd.Parameters.AddWithValue("@description", p.description);
            cmd.Parameters.AddWithValue("@projectURL", p.projectURL);
            cmd.Parameters.AddWithValue("@projectID", p.projectID);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void UpdateProjectMember(List<String> m)
        {
            // to be updated
        }
    }
}
