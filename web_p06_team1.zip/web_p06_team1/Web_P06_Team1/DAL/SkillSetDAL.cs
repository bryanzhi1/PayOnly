﻿using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using Web_P06_Team1.Models;
using System.Collections.Generic;
using System;
using Microsoft.AspNetCore.Mvc;

namespace Web_P06_Team1.DAL
{
    public class SkillSetDAL
    {
        private IConfiguration Configuration { get; set; }
        private SqlConnection conn;

        public SkillSetDAL()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
                "Student_EPorfolioConnectionString");
            conn = new SqlConnection(strConn);
        }

        public bool CheckId(string Id)
        {
            SqlCommand cmd = new SqlCommand("SELECT StudentId FROM Student WHERE StudentId = @StdId", conn);

            cmd.Parameters.AddWithValue("@StdId", Id);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "Count");
            conn.Close();

            if (result.Tables["Count"].Rows.Count == 1)
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        public bool CheckSkill(string Name)
        {
            SqlCommand cmd = new SqlCommand("SELECT SkillSetName FROM SkillSet WHERE SkillSetName LIKE @SklName");

            cmd.Parameters.AddWithValue("@SklName", Name);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "count");
            conn.Close();

            if (result.Tables["Count"].Rows.Count == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<SkillSet> GetSkills()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM SkillSet",conn);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "Skills");
            conn.Close();

            List<SkillSet> SkillList = new List<SkillSet>();
            foreach (DataRow dr in result.Tables["SkillSet"].Rows)
            {
                string Name = Convert.ToString(dr["SkillSetName"]);
                int SkillSetId = Convert.ToInt32(dr["SkillSetID"]);
                SkillSet ss = new SkillSet();
                ss.SkillSetId = SkillSetId;
                ss.Name = Name;
                SkillList.Add(ss);
                
            }

            return SkillList;
        }

        public Int32 GetStdID(String Name)
        {
            SqlCommand cmd = new SqlCommand("SELECT StudentID FROM Student WHERE Name = @Name",conn);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();

            cmd.Parameters.AddWithValue("@Name", Name);
            conn.Open();
            da.Fill(result, "StdID");
            conn.Close();

            int StdID = 0;

            foreach (DataRow row in result.Tables["StdID"].Rows)
            {
                StdID = Convert.ToInt32(row["StudentID"]);
            }

            return StdID;
        }


        public bool ChangeName(string NewName, string SkillName)
        {
            SqlCommand cmd = new SqlCommand("UPDATE SkillSet SET SkillSetName = @NewName OUTPUT UPDATED.SkillSetName WHERE SkillSetName = @SkillName",conn);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();

            conn.Open();
            da.Fill(result, "Count");
            conn.Close();

            if (result.Tables["Count"].Rows.Count == 1)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool RemoveSkill(string SkillName)
        {
            SqlCommand cmd = new SqlCommand("DELETE SkillSet WHERE SkillSetName = @SkillName",conn);

            return true;
        }

        public bool RemoveStdSkill(string Name, int SkillID)
        {
            SqlCommand cmd = new SqlCommand("DELETE StudentSkillSet WHERE StudentID = @StdID AND SkillSetID = @SkillID",conn);
            int StdID = GetStdID(Name);
            cmd.Parameters.AddWithValue("@StdID", StdID);
            cmd.Parameters.AddWithValue("@SkillID", SkillID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();

            if (StdID != 0)
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            else
            {

                return false;
            }
        }

        public List<int> GetAssignedStd(string Name)
        {
            List<int> StdList = new List<int>();
            SqlCommand cmd = new SqlCommand("SELECT StudentID FROM StudentSkillSet WHERE SkillSetID = @SkillID",conn);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            int SkillID = GetStdID(Name);
            cmd.Parameters.AddWithValue("@SkillID", SkillID);

            conn.Open();
            da.Fill(result, "IDs");
            conn.Close();
            foreach (DataRow row in result.Tables["IDs"].Rows)
            {
                int StdID = Convert.ToInt32(row["StudentID"]);
                StdList.Add(SkillID);

            }

            return StdList;

        }
        public List<int> GetAssignedSkills(string Name)
        {
            List<int> SkillList = new List<int>();
            SqlCommand cmd = new SqlCommand("SELECT SkillSetID FROM StudentSkillSet WHERE StudentID = @StdID",conn);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            int StdID = GetStdID(Name);
            cmd.Parameters.AddWithValue("@StdID", StdID);

            conn.Open();
            da.Fill(result, "IDs");
            conn.Close();
            foreach (DataRow row in result.Tables["IDs"].Rows)
            {
                int SkillID = Convert.ToInt32(row["SkillSetID"]);
                SkillList.Add(SkillID);

            }

            return SkillList;

        }

        public string GetSkillName(int ID)
        {
            string SkillName = null;
            SqlCommand cmd = new SqlCommand("SELECT SkillSetName FROM SkillSet WHERE SkillSetID = @ID",conn);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            cmd.Parameters.AddWithValue("@ID", ID);
            conn.Open();
            da.Fill(result, "SkillID");
            conn.Close();
            foreach (DataRow row in result.Tables["SkillSetName"].Rows)
            {
                SkillName = Convert.ToString(row["SkillSetName"]);

            }

            return SkillName;
        }

        public bool AddStdSkill(int SkillID, int StudentID)
        {
            // adds a skill to a student
            SqlCommand cmd1 = new SqlCommand("SELECT StudentID FROM StudentSkillSet sk"
                + " INNER JOIN Student st ON st.StudentID = sk.StudentID "
                + "WHERE st.StudentID = @StdID AND sk.SkillSetID = @SkillID",conn);
            //cmd 1 checks fto unsure 
            SqlCommand cmd2 = new SqlCommand("INSERT INTO StudentSkillSet (StudentID,SkillSetID) VALUES (@SkillID, @StdID)",conn);

            cmd2.Parameters.AddWithValue("@StdID", StudentID);
            cmd2.Parameters.AddWithValue("@SkillID", SkillID);
            cmd1.Parameters.AddWithValue("@StdID", StudentID);
            cmd1.Parameters.AddWithValue("@SkillID", SkillID);

            SqlDataAdapter da = new SqlDataAdapter(cmd1);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "Count");
            conn.Close();

            if (result.Tables["Count"].Rows.Count == 0)
            {
                conn.Open();
                cmd2.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            else
            {
                return false;
            }

        }

        public int GetSkillID(string Name)
        {
            SqlCommand cmd = new SqlCommand("SELECT SkillSetID FROM SkillSet WHERE SkillSetName LIKE @SklName",conn);
            int SkillName = 0;
            cmd.Parameters.AddWithValue("@SklName", Name);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "count");
            conn.Close();

            if (result.Tables["Count"].Rows.Count == 1)
            {
                foreach (DataRow row in result.Tables["SkillSetID"].Rows)
                {
                    SkillName = Convert.ToInt32(row["SkillSetID"]);

                }

                return SkillName;
            }
            else
            {
                return SkillName;
            }
        }

        public bool AddSkill(string Name)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO SkillSet(SkillSetName) OUTPUT INSERTED.SkillSetID VALUES (@SkillName)",conn);
            cmd.Parameters.AddWithValue("@SkillName", Name);
            conn.Open();
            int SkillSetId =(int)cmd.ExecuteScalar();
            conn.Close();

            return true;
        }

    }
}
