﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using Web_P06_Team1.Models;

namespace Web_P06_Team1.DAL
{
    public class StudentDAL
    {
        private IConfiguration Configuration { get; set; }
        private SqlConnection conn;

        public StudentDAL()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string strConn = Configuration.GetConnectionString(
                "Student_EPorfolioConnectionString");
            conn = new SqlConnection(strConn);
        }

        public bool accountChecker(string email, string pwd)
        {
            SqlCommand cmd = new SqlCommand
                ("SELECT StudentID FROM Student WHERE EmailAddr=@selectedEmail AND Password = @selectedPwd", conn);
            cmd.Parameters.AddWithValue("@selectedEmail", email);
            cmd.Parameters.AddWithValue("@selectedPwd", pwd);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "AccountDetails");
            conn.Close();

            if (result.Tables["AccountDetails"].Rows.Count == 1)
            {
                return true;
            }

            else
            {
                return false;
            }
        }

        public int Add(Student student)
        {
            //Generate ID and add lecturer to database and return true
            SqlCommand cmd = new SqlCommand
           ("INSERT INTO Student (Name, Course, Description, Achievement, ExternalLink, EmailAddr, Password, MentorID) " +
           "OUTPUT INSERTED.StudentID " +
           "VALUES(@name, @course, @description, @achievement, @externaLink, @email, @pwd, @mentorId)", conn);

            cmd.Parameters.AddWithValue("@name", student.Name.ToString());
            cmd.Parameters.AddWithValue("@course", student.Course.ToString());
            //cmd.Parameters.AddWithValue("@photo", student.Photo.ToString());
            cmd.Parameters.AddWithValue("@description", student.Description.ToString());
            cmd.Parameters.AddWithValue("@achievement", student.Achievement.ToString());
            cmd.Parameters.AddWithValue("@externaLink", student.ExternalLink.ToString());
            cmd.Parameters.AddWithValue("@email", student.Email.ToString());
            cmd.Parameters.AddWithValue("@pwd", "p@55Student");
            cmd.Parameters.AddWithValue("mentorId", student.MentorId.ToString());

            conn.Open();
            student.StudentId = (int)cmd.ExecuteScalar(); //Auto generate ID
            conn.Close();

            return student.StudentId;
        }

        public Student currentStudent(string email)
        {
            SqlCommand cmd = new SqlCommand
                ("SELECT * FROM Student WHERE EmailAddr=@selectedEmail", conn);
            cmd.Parameters.AddWithValue("@selectedEmail", email);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "Account");
            conn.Close();

            DataRow dr = result.Tables["Account"].Rows[0];
            Student s = new Student
            {
                StudentId = Convert.ToInt32(dr["StudentID"]),
                Name = dr["Name"].ToString(),
                Course = dr["Course"].ToString(),
                Description = dr["Description"].ToString(),
                Achievement = dr["Achievement"].ToString(),
                ExternalLink = dr["ExternalLink"].ToString(),
                Email = dr["EmailAddr"].ToString(),
                Password = dr["Password"].ToString(),
                MentorId = Convert.ToInt32(dr["MentorID"])
            };

            return s;
        }

        public bool IsEmailExist(string email)
        {
            //Check for existing email
            SqlCommand cmd = new SqlCommand
               ("SELECT StudentID FROM Student WHERE EmailAddr=@selectedEmail", conn);
            cmd.Parameters.AddWithValue("@selectedEmail", email);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet result = new DataSet();
            conn.Open();
            da.Fill(result, "AccountDetails");
            conn.Close();

            if (result.Tables["AccountDetails"].Rows.Count > 1)
            {
                return true;
            }

            else
            {
                return false;
            }
        }
    }
}
