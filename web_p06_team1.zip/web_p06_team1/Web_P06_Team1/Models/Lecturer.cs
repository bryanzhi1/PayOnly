﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Web_P06_Team1.Models
{
    public class Lecturer
    {
        public int LecturerId { get; set; }

        [Display(Name="Name")]
        [Required(ErrorMessage = "A name is required.")]
        [StringLength(50, ErrorMessage = "Enter no more than 50 characters.")]
        public string Name { get; set; }

        [Display(Name = "Email Address")]
        [Required(ErrorMessage = "An email is required.")]
        [DisplayFormat(DataFormatString = "^([\\w\\.\\-]+)@([\\w\\-]+)((\\.(\\w){2,3})+)$")]
        [ValidateEmailExists(ErrorMessage = "Email address already exists!")]
        public string Email { get; set; }

        [Display(Name="Password")]
        public string Password { get; set; }

        [Display(Name="Professional Description")]
        [StringLength(3000, ErrorMessage = "Enter no more than 3000 characters.")]
        public string Description { get; set; }
    }
}
