﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Web_P06_Team1.Models
{
    public class Project
    {                 
        [Display(Name = "Project ID")]
        public int projectID { get; set; }
        [Display(Name = "Title")]
        [StringLength(255, ErrorMessage = "Please enter a shorter title.")]
        [Required]
        public string title { get; set; }
        [Display(Name = "Description")]
        [StringLength(3000, ErrorMessage = "Please enter a shorter description.")]
        public string description { get; set; }
        [Display(Name = "Project Poster")]
        [StringLength(255, ErrorMessage = "Please enter a shorter filename.")]
        public string projectPoster { get; set; }
        [Display(Name = "Project URL")]
        [StringLength(255, ErrorMessage = "Please enter a shorter URL.")]
        public string projectURL { get; set; }
    }
}
