﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Web_P06_Team1.Models
{
    public class ProjectMember
    {
        // ProjectID*
        [Display(Name = "Project ID")]
        [Required(ErrorMessage = "Project ID is required")]
        public int ProjectId { get; set; }

        // StudentID*
        [Display(Name = "Student ID")]
        [Required(ErrorMessage = "Student ID is required")]
        public int StudentId { get; set; }

        // Role
        [Display(Name = "Role")]
        [Required(ErrorMessage = "Role is required")]
        [StringLength(50, ErrorMessage = "Max 50 words")]
        public string Role { get; set; }
    }
}
