﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Web_P06_Team1.Models
{
    public class ProjectViewModel
    {
        [Display(Name = "ProjectID")]
        public int projectID { get; set; }
        [Display(Name = "Title")]
        public string title { get; set; }
        [Display(Name = "Description")]
        public string description { get; set; }
        [Display(Name = "Project Poster")]
        public string projectPoster { get; set; }
        [Display(Name = "Project URL")]
        public string projectURL { get; set; }
        [Display(Name = "Student List")]
        public List<String> studentList { get; set; }
        public List<String> roleList { get; set; }
    }
}
