﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Web_P06_Team1.Models
{
    public class SkillSet
    {
        // Skill Set ID*
        [Display(Name = "Skill Set ID")]
        [Required(ErrorMessage = "Skill Set ID is required")]
        public int SkillSetId { get; set; }

        // Skill Set Name*
        [Display(Name = "Skill Set Name")]
        [Required(ErrorMessage = "Please a skill set name")]
        [StringLength(255, ErrorMessage = "Max 50 words")]
        public string Name { get; set; }
    }
}
