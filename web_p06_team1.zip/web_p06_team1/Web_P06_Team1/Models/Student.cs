﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Web_P06_Team1.Models
{
    public class Student
    {
        // StudentID*
        [Display(Name = "sID")]
        [Required]
        public int StudentId { get; set; }

        // Student Name*
        [Display(Name = "Name")]
        [Required(ErrorMessage ="Please enter your name!")]
        [StringLength(50, ErrorMessage = "Max 50 words")]
        public string Name { get; set; }

        // Student Course*
        [Display(Name = "Course")]
        [Required(ErrorMessage ="Please enter a course")]
        [StringLength(50, ErrorMessage = "Max 50 words")]
        public string Course { get; set; }

        // Student Photo
        [Display(Name = "Photo")]
        [StringLength(255, ErrorMessage = "Max 255 words")]
        public string Photo { get; set; }

        // Student Description
        [Display(Name = "Description")]
        [StringLength(3000, ErrorMessage = "Max 3000 words")]
        public string Description { get; set; }

        // Student Achievement
        [Display(Name = "Achievement")]
        [StringLength(3000, ErrorMessage = "Max 3000 words")]
        public string Achievement { get; set; }

        // Student ExternalLink
        [Display(Name = "External Link")]
        [StringLength(255, ErrorMessage = "Max 255 words")]
        public string ExternalLink { get; set; }

        // Student EmailAddress*
        [Required(ErrorMessage = "Please enter the student email address")]
        [EmailAddress]
        [ValidateEmailExists(ErrorMessage = "Email address already exist!")]
        [StringLength(50, ErrorMessage = "Max 50 words")]
        public string Email { get; set; }

        // Student Password*
        [Required(ErrorMessage = "Please enter the password")]
        [StringLength(255, ErrorMessage = "Max 255 words")]
        public string Password { get; set; }

        //Student's Mentor*
        [Required(ErrorMessage = "Please enter Mentor's ID")]
        public int MentorId { get; set; }
    }
}
