﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Web_P06_Team1.Models
{
    public class StudentSkillSet
    {
        //StudentID*
        [Required]
        public int StudentId { get; set; }
        //SkillSetID*
        [Required]
        public int SkillSetId { get; set; }
    }
}
