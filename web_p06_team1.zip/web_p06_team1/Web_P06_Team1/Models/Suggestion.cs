﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Web_P06_Team1.Models
{
    public class Suggestion
    {
        // Suggestion ID*
        [Display(Name = "Suggestion ID")]
        [Required(ErrorMessage = "Suggestion ID is required")]
        public int SuggestionId { get; set; }

        //Student Name
        public string StudentName { get; set; }

        // Lecturer ID*
        [Display(Name = "Lecturer ID")]
        [Required(ErrorMessage = "Lecturer ID is required")]
        public int LecturerId { get; set; }

        // Student ID*
        [Display(Name = "Student ID")]
        [Required(ErrorMessage = "Student ID is required")]
        public int StudentId { get; set; }

        // Description
        [Display(Name = "Description")]
        public string Description { get; set; }

        // Status*
        [Display(Name = "Status")]
        [Required(ErrorMessage = "Status is required")]
        public char Status { get; set; }

        // DateCreated*
        [Display(Name = "Date Created")]
        [Required(ErrorMessage = "DateCreated is required")]
        public DateTime DateCreated { get; set; }
    }
}
