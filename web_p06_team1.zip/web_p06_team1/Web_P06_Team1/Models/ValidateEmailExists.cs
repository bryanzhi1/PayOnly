﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Web_P06_Team1.DAL;

namespace Web_P06_Team1.Models
{
    public class ValidateEmailExists : ValidationAttribute
    {
        private LecturerDAL lecturerContext = new LecturerDAL();

        public override bool IsValid(object value)
        {
            string email = Convert.ToString(value);
            if (lecturerContext.IsEmailExist(email))
            {
                return false;
            }

            else
            {
                return true;
            }
        }
    }
}
